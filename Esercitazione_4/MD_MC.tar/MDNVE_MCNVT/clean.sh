rm -rf *.dat
rm -rf frames/*.xyz
